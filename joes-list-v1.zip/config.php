<?php
// Database Configuration - FILL THIS OUT
define('DB_HOST', 'localhost');
define('DB_USER', 'refluxed_joes_list_db');
define('DB_PASS', '(C[(_B!+zHy7j8*L');
define('DB_NAME', 'refluxed_joes_list_db');

// App Config
define('SITE_URL', 'https://joeslist.refluxedpc.com/');
define('UPLOAD_PATH', __DIR__ . '/uploads/');
define('SESSION_LIFETIME', 3600); // 1 hour
?>