<?php


// config.php
// Fill these in before running install.php
return [
'db_host' => 'localhost',
'db_name' => 'refluxed_links',
'db_user' => 'refluxed_surfzilla',
'db_pass' => 'Vcbd]VvcP}mR]_Pq',
'table_prefix' => 'r_', // change if you want
'base_url' => 'https://api.refluxedpc.com/links/', // change to your local URL
];


// Notes: the installer (install.php) will try to use these credentials to connect and create tables.
?>