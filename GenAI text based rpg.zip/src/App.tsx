import { useState, useEffect } from 'react'
import { ImageWithFallback } from './components/figma/ImageWithFallback'
import { Button } from './components/ui/button'
import { Header } from './components/Header'
import { FeatureCards } from './components/FeatureCards'
import { CampaignList } from './components/CampaignList'
import { SplashScreen } from './components/SplashScreen'

export default function App() {
  const [currentView, setCurrentView] = useState<'splash' | 'landing' | 'campaigns'>('splash')
  
  // Override global body background with Doom theme (red/orange)
  useEffect(() => {
    document.body.style.background = 'linear-gradient(135deg, rgb(139 0 0), rgb(178 34 34), rgb(128 0 0))'
  }, [])

  // Show splash screen first
  if (currentView === 'splash') {
    return <SplashScreen onEnter={() => setCurrentView('landing')} />
  }

  if (currentView === 'campaigns') {
    return <CampaignList />
  }

  return (
    <div className="min-h-screen">
      {/* Background Section */}
      <div className="relative min-h-screen">
        {/* Doom Hellscape Background Image */}
        <ImageWithFallback 
          src="https://images.unsplash.com/photo-1629728849536-02e9fe984513?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWxsc2NhcGUlMjByZWQlMjBkYXJrJTIwaW5kdXN0cmlhbHxlbnwxfHx8fDE3NjE1NDc2ODh8MA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Hellscape background"
          className="absolute inset-0 w-full h-full object-cover"
        />
        
        {/* Red/Orange Doom Overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-red-900/60 via-orange-900/50 to-red-950/70" />
        
        {/* Content over background */}
        <div className="relative z-10 min-h-screen flex flex-col">
          <Header />
          
          {/* Main Content - Upper portion */}
          <main className="flex-1 flex flex-col items-center justify-start px-6 pt-8 pb-12">
            <div className="text-center max-w-4xl mx-auto">
              {/* Welcome Section */}
              <div className="mb-16">
                <h1 className="text-6xl md:text-7xl text-white mb-6 drop-shadow-[0_0_15px_rgba(255,0,0,0.5)]">
                  RIP AND TEAR
                </h1>
                <p className="text-xl text-orange-200 mb-12 max-w-2xl mx-auto leading-relaxed drop-shadow-lg">
                  The demons have breached our reality. The UAC facility on Mars has opened a gateway to Hell itself. Gear up, Marine. It's time to send them back where they came from.
                </p>
              </div>

              {/* Forge Your Legend Section */}
              <div className="mb-16">
                <h2 className="text-5xl text-white mb-8 drop-shadow-[0_0_10px_rgba(255,0,0,0.4)]">
                  ENTER THE SLAUGHTER
                </h2>
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-red-700 to-orange-600 hover:from-red-800 hover:to-orange-700 text-white px-16 py-6 text-xl rounded-lg shadow-lg hover:shadow-[0_0_30px_rgba(255,0,0,0.5)] transition-all duration-300 border-2 border-red-900"
                  onClick={() => setCurrentView('campaigns')}
                >
                  💀 START YOUR CAMPAIGN 💀
                </Button>
              </div>
            </div>
          </main>

          {/* Bottom section for Feature Cards */}
          <div className="h-48 flex items-center justify-center px-6">
            <FeatureCards />
          </div>
        </div>
      </div>
    </div>
  )
}
