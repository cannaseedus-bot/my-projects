import { useState, useEffect } from 'react'
import splashLogo from 'figma:asset/953e0066233f14bed537891baa05ab2c30914d15.png'
import { Button } from './ui/button'

interface SplashScreenProps {
  onEnter: () => void
}

export function SplashScreen({ onEnter }: SplashScreenProps) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    // Fade in animation
    setTimeout(() => setIsVisible(true), 100)
  }, [])

  return (
    <div 
      className={`min-h-screen relative overflow-hidden transition-opacity duration-1000 ${isVisible ? 'opacity-100' : 'opacity-0'}`}
    >
      {/* Animated Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-red-950 to-orange-950 animate-pulse" 
           style={{ animationDuration: '4s' }} 
      />
      
      {/* Darker Vignette Effect */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.7)_100%)]" />
      
      {/* Flame particles effect (simulated with gradients) */}
      <div className="absolute inset-0">
        <div className="absolute bottom-0 left-1/4 w-32 h-32 bg-orange-600/20 rounded-full blur-3xl animate-pulse" 
             style={{ animationDelay: '0s', animationDuration: '3s' }} 
        />
        <div className="absolute bottom-10 right-1/4 w-40 h-40 bg-red-700/20 rounded-full blur-3xl animate-pulse" 
             style={{ animationDelay: '1s', animationDuration: '4s' }} 
        />
        <div className="absolute top-1/3 left-1/3 w-24 h-24 bg-orange-500/10 rounded-full blur-2xl animate-pulse" 
             style={{ animationDelay: '2s', animationDuration: '5s' }} 
        />
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-6">
        {/* Logo Container */}
        <div className="mb-12 transform hover:scale-105 transition-transform duration-500">
          <img 
            src={splashLogo} 
            alt="World of Doom Logo" 
            className="w-full max-w-2xl h-auto drop-shadow-[0_0_50px_rgba(255,69,0,0.8)] animate-pulse"
            style={{ animationDuration: '3s' }}
          />
        </div>

        {/* Tagline */}
        <div className="text-center mb-12">
          <p className="text-2xl md:text-3xl text-orange-200 mb-4 drop-shadow-[0_0_10px_rgba(255,140,0,0.8)] tracking-wider">
            WHERE HELL MEETS RPG
          </p>
          <p className="text-lg text-orange-300/80 drop-shadow-lg">
            Face the hordes. Level up. Survive.
          </p>
        </div>

        {/* Enter Button */}
        <Button
          size="lg"
          onClick={onEnter}
          className="group relative bg-gradient-to-r from-red-800 to-orange-700 hover:from-red-900 hover:to-orange-800 text-white px-20 py-8 text-2xl rounded-lg shadow-[0_0_40px_rgba(255,0,0,0.6)] hover:shadow-[0_0_60px_rgba(255,69,0,0.9)] transition-all duration-500 border-4 border-red-900/50 hover:border-orange-600/70 transform hover:scale-110"
        >
          <span className="relative z-10 flex items-center gap-3">
            <span className="animate-pulse" style={{ animationDuration: '2s' }}>🔥</span>
            <span className="tracking-widest">ENTER HELL</span>
            <span className="animate-pulse" style={{ animationDuration: '2s' }}>🔥</span>
          </span>
          
          {/* Glowing effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-red-600 opacity-0 group-hover:opacity-30 blur-xl transition-opacity duration-500 rounded-lg" />
        </Button>

        {/* Footer text */}
        <p className="mt-12 text-sm text-orange-400/60 text-center max-w-md drop-shadow-md">
          "In the first age, in the first battle, when the shadows first lengthened, one stood..."
        </p>
      </div>

      {/* Bottom glow effect */}
      <div className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-orange-900/30 to-transparent pointer-events-none" />
    </div>
  )
}
