import { Skull, Flame, Target } from 'lucide-react'

export function FeatureCards() {
  const features = [
    {
      icon: Skull,
      title: 'Demon Slaying',
      description: 'Face hordes of hellspawn with an arsenal of devastating weapons and brutal glory kills'
    },
    {
      icon: Flame,
      title: 'Hell on Earth',
      description: 'Explore demonic portals, UAC facilities, and the depths of Hell itself in procedural missions'
    },
    {
      icon: Target,
      title: 'Tactical Combat',
      description: 'Master strategic demon-hunting with RPG mechanics, upgrades, and intense tactical decisions'
    }
  ]

  return (
    <div className="flex flex-row justify-center items-center gap-8 max-w-6xl mx-auto">
      {features.map((feature, index) => {
        const Icon = feature.icon
        return (
          <div key={index} className="bg-black/60 backdrop-blur-md rounded-lg border border-red-700/40 hover:border-orange-500/60 hover:bg-black/50 transition-all duration-300 p-6 w-80 h-48 flex flex-col items-center justify-center text-center hover:shadow-[0_0_20px_rgba(255,0,0,0.3)]">
            <div className="w-16 h-16 mb-4 bg-red-800/40 rounded-full flex items-center justify-center backdrop-blur-sm border border-red-600/50 shadow-[0_0_15px_rgba(255,0,0,0.3)]">
              <Icon className="w-8 h-8 text-orange-300" />
            </div>
            <h3 className="text-white text-xl mb-3 drop-shadow-lg">{feature.title}</h3>
            <p className="text-orange-100 text-sm leading-relaxed drop-shadow-md">{feature.description}</p>
          </div>
        )
      })}
    </div>
  )
}
