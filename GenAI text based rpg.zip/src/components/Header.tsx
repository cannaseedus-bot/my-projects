import { Badge } from './ui/badge'
import { Avatar, AvatarFallback } from './ui/avatar'

export function Header() {
  return (
    <header className="w-full bg-gradient-to-r from-red-950/90 to-orange-950/90 backdrop-blur-sm border-b border-red-800/50">
      <div className="container mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo and Brand */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-red-700 to-orange-600 rounded-lg flex items-center justify-center shadow-lg">
            <span className="text-white text-xl">💀</span>
          </div>
          <div>
            <h1 className="text-white text-xl">DOOM RPG</h1>
            <p className="text-orange-200 text-sm">UAC Mars Facility</p>
          </div>
        </div>

        {/* Center Badge */}
        <Badge variant="outline" className="bg-red-900/50 text-orange-100 border-red-700/50">
          🔥 HELLSCAPE
        </Badge>

        {/* Profile Section */}
        <div className="flex items-center space-x-4">
          <div className="text-right">
            <p className="text-white">Doom Slayer</p>
            <p className="text-orange-200 text-sm">slayer@uac-mars.com</p>
          </div>
          <Avatar className="w-10 h-10">
            <AvatarFallback className="bg-red-700 text-white">DS</AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  )
}
