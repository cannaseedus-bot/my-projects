import { useState } from 'react'
import { Button } from './ui/button'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Badge } from './ui/badge'
import { Plus, Users, Calendar, Skull, Flame, Crosshair, Target, Settings, Play } from 'lucide-react'

interface Campaign {
  id: string
  title: string
  description: string
  theme: 'mars-base' | 'hell-portal' | 'demon-nest'
  players: number
  maxPlayers: number
  lastPlayed: string
  status: 'active' | 'recruiting' | 'completed'
  difficulty: 'rookie' | 'veteran' | 'nightmare'
}

const mockCampaigns: Campaign[] = [
  {
    id: '1',
    title: 'UAC Mars Facility',
    description: 'The Union Aerospace Corporation\'s research facility has been overrun by demons. Fight through the industrial complex and close the Hell portal before it\'s too late.',
    theme: 'mars-base',
    players: 4,
    maxPlayers: 6,
    lastPlayed: '2 days ago',
    status: 'active',
    difficulty: 'veteran'
  },
  {
    id: '2', 
    title: 'The Ninth Circle',
    description: 'Descend into the deepest layers of Hell itself. Navigate treacherous demon territories and face the Icon of Sin in this ultimate test of survival.',
    theme: 'hell-portal',
    players: 3,
    maxPlayers: 5,
    lastPlayed: '1 week ago',
    status: 'recruiting',
    difficulty: 'nightmare'
  },
  {
    id: '3',
    title: 'Demon Invasion',
    description: 'Earth\'s cities have become demon breeding grounds. Lead tactical strikes against nests and save humanity from complete annihilation.',
    theme: 'demon-nest',
    players: 5,
    maxPlayers: 6,
    lastPlayed: '3 days ago',
    status: 'active',
    difficulty: 'rookie'
  }
]

const themeColors = {
  'mars-base': 'bg-gradient-to-br from-orange-700/20 to-red-800/20 border-orange-600/30',
  'hell-portal': 'bg-gradient-to-br from-red-700/20 to-red-950/20 border-red-600/30',
  'demon-nest': 'bg-gradient-to-br from-amber-700/20 to-orange-800/20 border-amber-600/30'
}

const statusColors = {
  active: 'bg-green-500/20 text-green-300 border-green-500/30',
  recruiting: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
  completed: 'bg-gray-500/20 text-gray-300 border-gray-500/30'
}

const difficultyIcons = {
  rookie: Target,
  veteran: Crosshair,
  nightmare: Skull
}

export function CampaignList() {
  const [campaigns] = useState<Campaign[]>(mockCampaigns)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-red-950 to-slate-900">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl text-white mb-2 drop-shadow-[0_0_10px_rgba(255,0,0,0.5)]">Your Campaigns</h1>
            <p className="text-orange-200">Choose your mission or start a new demon hunt</p>
          </div>
          <Button 
            size="lg"
            className="bg-gradient-to-r from-red-700 to-orange-600 hover:from-red-800 hover:to-orange-700 text-white px-6 py-3 rounded-lg shadow-lg hover:shadow-[0_0_20px_rgba(255,0,0,0.4)] transition-all duration-300 border-2 border-red-900"
          >
            <Plus className="w-5 h-5 mr-2" />
            Create New Campaign
          </Button>
        </div>

        {/* Campaign Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {campaigns.map((campaign) => {
            const DifficultyIcon = difficultyIcons[campaign.difficulty]
            
            return (
              <Card 
                key={campaign.id} 
                className={`bg-black/60 backdrop-blur-sm border hover:bg-black/70 transition-all duration-300 hover:scale-105 hover:shadow-[0_0_25px_rgba(255,0,0,0.2)] ${themeColors[campaign.theme]}`}
              >
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-white text-xl">{campaign.title}</CardTitle>
                    <Badge className={`${statusColors[campaign.status]} capitalize`}>
                      {campaign.status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-orange-200">
                    <DifficultyIcon className="w-4 h-4" />
                    <span className="capitalize">{campaign.difficulty}</span>
                    <span className="text-orange-300/50">•</span>
                    <span className="capitalize">{campaign.theme.replace('-', ' ')}</span>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <p className="text-orange-100 text-sm leading-relaxed line-clamp-3">
                    {campaign.description}
                  </p>
                  
                  <div className="flex justify-between items-center text-sm">
                    <div className="flex items-center gap-2 text-orange-200">
                      <Users className="w-4 h-4" />
                      <span>{campaign.players}/{campaign.maxPlayers} marines</span>
                    </div>
                    <div className="flex items-center gap-2 text-orange-200">
                      <Calendar className="w-4 h-4" />
                      <span>{campaign.lastPlayed}</span>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    <Button 
                      variant="default" 
                      size="sm" 
                      className="flex-1 bg-red-700 hover:bg-red-800 text-white border border-red-900"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      {campaign.status === 'recruiting' ? 'Join' : 'Continue'}
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="border-red-700/50 text-orange-200 hover:bg-red-900/30"
                    >
                      <Settings className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
          
          {/* Create New Campaign Card */}
          <Card className="bg-black/40 backdrop-blur-sm border-dashed border-red-600/50 hover:border-orange-500/70 hover:bg-black/50 transition-all duration-300 flex items-center justify-center min-h-[300px] cursor-pointer group">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-red-800/30 rounded-full flex items-center justify-center group-hover:bg-red-700/40 transition-colors">
                <Plus className="w-8 h-8 text-orange-300" />
              </div>
              <h3 className="text-white text-xl mb-2">Start New Mission</h3>
              <p className="text-orange-200 text-sm">Create a custom campaign and hunt demons</p>
            </div>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button 
            variant="outline" 
            size="lg" 
            className="border-red-700/50 text-orange-200 hover:bg-red-900/30 h-16"
          >
            <Target className="w-6 h-6 mr-3" />
            Browse Missions
          </Button>
          <Button 
            variant="outline" 
            size="lg" 
            className="border-red-700/50 text-orange-200 hover:bg-red-900/30 h-16"
          >
            <Users className="w-6 h-6 mr-3" />
            Find Marines
          </Button>
          <Button 
            variant="outline" 
            size="lg" 
            className="border-red-700/50 text-orange-200 hover:bg-red-900/30 h-16"
          >
            <Flame className="w-6 h-6 mr-3" />
            AI Demon Master
          </Button>
        </div>
      </div>
    </div>
  )
}
