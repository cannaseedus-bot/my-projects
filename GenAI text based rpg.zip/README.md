
  # GenAI text based rpg

  This is a code bundle for GenAI text based rpg. The original project is available at https://www.figma.com/design/lp9ZWboSLy8yeulM820iBy/GenAI-text-based-rpg.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  